# ***** BEGIN LICENSE BLOCK *****
#
# For copyright and licensing please refer to COPYING.
#
# ***** END LICENSE BLOCK *****
from setuptools import setup
import os

# Conditionally include additional modules for docs
on_rtd = os.environ.get('READTHEDOCS', None) == 'True'
requirements = list()
if on_rtd:
    requirements.append('pika')
    requirements.append('twisted')
    requirements.append('pyev')

long_description = ('Echo is a pure-Python implementation of the PIKA')

setup(name='echo',
      version='1.2.0',
      description='Echo Python ',
      long_description=long_description,
      maintainer='echo team',
      maintainer_email='echo@firstdata.com',
      url='https://echo.readthedocs.org ',
      packages=['echo'],
      license='MPL v2.0',
      install_requires=requirements,
      package_data={'': ['LICENSE', 'README.md']},
      extras_require={'tornado': ['tornado'],
                      'twisted': ['twisted'],
                      'libev': ['pyev']},
      classifiers=[
          'Development Status :: 5 - Production/Stable',
          'Natural Language :: English',
          'Operating System :: OS Independent',
          'Programming Language :: Python :: 2.6',
          'Programming Language :: Python :: 2.7',
          'Topic :: Communications',
          'Topic :: System :: Networking'],
      zip_safe=True)