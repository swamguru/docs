import pika
import json
import logging
from dolphind.lib.base_worker import BaseWorker

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(levelname)-8s %(message)s',
                    datefmt='%a, %d %b %Y %H:%M:%S',
                    filename='/etc/dolphind/logs/poc.log')

class LogWorker(BaseWorker):
	queue_name = 'logmanager_queue'

	def __init__(self):
		super(LogWorker, self).__init__(self.queue_name)

	def callback(self, ch, method, properties, body):
		#import pdb;pdb.set_trace()
		print " Log Worker [x] Received %r" % (body,)
		body_json = json.loads(body)
		logging.info(" Log Worker [x] Received %r" % (body,))
		ch.basic_ack(delivery_tag = method.delivery_tag)

#----------------------
if __name__ == '__main__':
	LogObj = LogWorker()
	LogObj.run()
