from dolphind.utils.dbconnectors.cassandra_connector import Cassandra_Connector

def read_workflow():
    con_obj = Cassandra_Connector(key_space='echo')
    con_obj.connect()
    result = con_obj.select('workflow_config', where={'task_name':'d1_server_info'})
    print result

read_workflow()
