"""
Requirements:
Implement RouteWorker class which is derived from BaseWorker class 
-Reads workflow config file from Cassandra workflow_config table and updates the message header. 
-Based on workflow config and OK = True, then publish the message to next queue and also fans/direct out to log queue. 
-Update the task/subtask status in Cassandra task_details/subtask_details. 
-If there is no further queue checks whether the header has aggregator-reply-to-queue attribute and if found
posts the msg to that queue with setting aggregator-reply-to-queue attibute as null.
- if it receives a msg from aggregator worker it sets the task status as complete and exits the flow
"""

import sys
import pika
import json
import yaml
import traceback
import datetime
from ast import literal_eval as leval

from dolphind.lib.base_worker import BaseWorker
from dolphind.lib.cassandra_connector import Cassandra_Connector


class RouteWorker(BaseWorker):
    queue_name = 'routemanager_queue'

    def __init__(self):
        super(RouteWorker, self).__init__(self.queue_name)
        self.con_obj = Cassandra_Connector(key_space='dolphind')
        self.con_obj.connect()


    def get_workflow(self, task_name):
        'From cassandra table gets the corresponding workflow for the task'
        try:
            res = self.con_obj.select('workflow_config', what=['workflow_config', ], where={'task_name':task_name})
            workflow = json.loads(res[0]['workflow_config'])
            return workflow
        except:
            print traceback.format_exc()
            return None


    def get_next_queue(self, workflow, msg_from):
        'Returns the next queue in the workflow to post the message'
        try:
            for task in workflow:
                if task['worker-id'] == msg_from:
                    return task['next-queue']
            return None
            #return [task['next-queue'] for task in workflow if task['worker-id']==msg_from][0]
        except IndexError:
            print 'No next queue defined..'
            return Noneget_next_queue


    def form_msg_header(self, header_data, next_queue):
        'Returns the header that will be used for posting to next queue'
        if next_queue:
            header_data['ok'] = "True"
            return header_data
        elif header_data['aggregator-reply-to-queue']:
            header_data['aggregator-reply-to-queue'] = None
            return header_data


    def send_msg(self, ch, header_data, body, next_queue):
        'Posts the message to the next queue'
        payload_data = {}
        new_header_data = self.form_msg_header(header_data, next_queue)
        payload_data["msg-header"] = [new_header_data]
        payload_data["msg-body"] = body
        try:
            ch.exchange_declare(exchange=next_queue, type='fanout')
            ch.queue_bind(exchange=next_queue, queue=next_queue)
            ch.queue_bind(exchange=next_queue, queue='logmanager_queue')
            # Call Next queue and Push
            ch.basic_publish(exchange=next_queue,
                            routing_key='',
                            body=json.dumps(payload_data),
                            properties=pika.BasicProperties(
                                delivery_mode = 2,)) # make message persistent
        except pika.exceptions.ChannelClosed:
            print 'channel closed..'

    def callback(self, ch, method, properties, body):
        'The callback method specific for route worker extended from the base class'

        print " RouteWorker Worker [x] Received %r" % (body,)
        payload_data = yaml.load(body)
        header_data = payload_data['msg-header'][0]
        msg_body = payload_data['msg-body']

        if not leval(header_data['ok']) or leval(header_data['error-msg']):
            if header_data['sub-task-id']:
                try:
                    update_items = {'status' :'ER','error' : header_data['error-msg']}
                    where_condition = {'id' : int(header_data["sub-task-id"])}
                    self.con_obj.update("sub_task_details", update_items, where_condition)
                    print "ERROR OCCURED - OK attribute is False"
                    next_queue = header_data['aggregator-reply-to-queue']
                    self.send_msg(ch, header_data, msg_body, next_queue)    
                    ch.basic_ack(delivery_tag = method.delivery_tag)
                    return
                except :
                    print "ERROR Route Manager :: Could not update"
            try:
                update_items = {'status' :'FD','error' : header_data['error-msg']}
                where_condition = {'id' : int(header_data['task-id'])}
                self.con_obj.update("task_details", update_items, where_condition)
                ch.basic_ack(delivery_tag = method.delivery_tag)
                print "ERROR OCCURED - OK attribute is False"
                return
            except :
                print "ERROR Route Manager :: Could not update"

        task_id = header_data["task-id"]
        task_name = header_data["task-name"]
        workflow = self.get_workflow(task_name)
        if not workflow:
            print 'workflow not found; exiting'
            return
        msg_from = header_data['from-worker']
        next_queue = self.get_next_queue(workflow, msg_from)
        
        if next_queue:
            try:
                update_items = {'status':'IP'}
                where_condition = {'id' : int(header_data['task-id'])}
                self.con_obj.update('task_details',update_items,where_condition)
            except:
                print "ERROR Route Manager :: Could not update task table"
            self.send_msg(ch, header_data, msg_body, next_queue)
        else:
            try:
                dt = datetime.datetime.now().replace(microsecond=0)
                dt = str(dt)
                result = { "summation" : msg_body["sum"], "multiplication" : msg_body["result_multiplication"]}
                update_items = {'status':'CM', 'cmpl_time':dt, 'reply' : json.dumps(result)}
                where_condition = {'id' : int(header_data['task-id'])}
                self.con_obj.update('task_details',update_items,where_condition)
                print "Workflow Complete"
            except Exception as err:
                print "Error Routemanager :: could not update complete status"+str(err)
        ch.basic_ack(delivery_tag = method.delivery_tag)

#----------------------------------------------------
if __name__ == '__main__':
    worker_obj = RouteWorker()
    worker_obj.run()
