"""
This worker will consume from echo.dolphind.queue.request queue and saves the request into a columnfamily in cassandra.
the columnfamily is task_details
task_id - task-request-id from the request
task_payload - payload from the request
task_status: RC - RECEIVED , IP - InProgress, ER - ERROR, FD - FAILED, CM - Complete
task_error : error message
Then post the msg to the route queue
"""

import pika
import json
import datetime
from dolphind.lib.base_worker import BaseWorker
from dolphind.config.config import msg_header
from dolphind.lib.cassandra_connector import Cassandra_Connector
from dolphind.lib import msg


class RequestWorker(BaseWorker):
	queue_name = 'requestmanager_queue'

	def __init__(self):
		super(RequestWorker, self).__init__(self.queue_name)
		self.con_obj = Cassandra_Connector(key_space='dolphind')
		self.con_obj.connect()

	def _form_msg_header(self, header_data, next_queue):
		'Forms the msg header by changing values of the default header with the task specific data'
		msg_header['task-id'] = header_data['task-id']
		msg_header['task-name'] = header_data['task-name']
		msg_header['from-worker'] = 'request_worker'
		return msg_header


	def send_msg(self, ch, payload, next_queue):
		'Posts msg to the next queue'
		payload_data = {}
		new_header_data = self._form_msg_header(payload.header_data, next_queue)
		payload_data["msg-header"] = [new_header_data]
		payload_data["msg-body"] = payload.body
		try:
		    # Call Next queue and Push
		    ch.basic_publish(exchange= '',
		                    routing_key=next_queue,
		                    body=json.dumps(payload_data),
		                    properties=pika.BasicProperties(
		                        delivery_mode = 2,)) # make message persistent
		except pika.exceptions.ChannelClosed:
		    print 'channel closed..'


	def callback(self, ch, method, properties, body):
		'The callback method specific for request worker extended from the base class'
		print " Request Worker [x] Received %r" % (body,)
		rec_msg = msg.Msg(body)
		try:
			save_data = {}
			dt_str = rec_msg.header_data['task-submitted-date_time']
			fmt = '%Y-%m-%d %H:%M:%S.%f'
			dt = datetime.datetime.strptime(dt_str, fmt).replace(microsecond=0)
			save_data['id'] = int(rec_msg.task_id)
			save_data['name'] = rec_msg.header_data['task-name']
			save_data['subm_time'] = dt
			save_data['request'] = rec_msg.body[0] #this will be the location of the file in local filesystem
			save_data['status'] = 'RC'
			self.con_obj.insert("task_details", values=[save_data,])
		except Exception as err:
			print 'Exception while inserting into task_details'+str(err)
		next_queue = 'routemanager_queue'
		self.send_msg(ch, rec_msg, next_queue)
		ch.basic_ack(delivery_tag = method.delivery_tag)


#----------------------------------------------------
if __name__ == '__main__':
    worker_obj = RequestWorker()
    worker_obj.run()
