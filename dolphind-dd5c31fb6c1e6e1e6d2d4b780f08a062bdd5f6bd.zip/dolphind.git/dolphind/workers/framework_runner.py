"""
This module is used for supervisor 

"""

import sys
import argparse
import ConfigParser
import json
import os

from dolphind.workers.route_worker  import RouteWorker
from dolphind.workers.request_worker import RequestWorker
from dolphind.workers.retry_worker import RetryWorker
from dolphind.workers.log_worker import LogWorker
from dolphind.utils.utils import config_section_map


worker_types = {
				#'request_worker':RequestWorker,
				'route_worker':RouteWorker,
				#'retry_worker':RetryWorker,
				#'log_worker':LogWorker,
			   }


class FrameWorkerRunner(object):
	def __init__(self):
		'''
		Creates as many worker processes based the configuration file.
		'''
		conf_file_path = os.path.dirname(os.path.realpath(__file__)) + \
					"/../config/base_worker_config.cfg"

		Config = ConfigParser.ConfigParser()
		Config.read(conf_file_path)


		for key, value in worker_types.items():
			conf = config_section_map(Config,key)

			# loop it based on numprocs values.
			for num in range(int(conf['numprocs'])):
				obj =  value() # dynamically create a object for the class from the dict.
				obj.start()

#------------------------
if __name__ == '__main__':
	FrameWorkerRunner()

	