#!/usr/bin/env python
# *- coding: utf-8 -*-
"""
Node Monitor DolphinD.workers.NodeMonitorWorker
"""
from dolphind.lib.base_worker import BaseWorker
from examples.registration_usecase.workers.aggregate_worker import AggregateWorker as AW
import pika
import settings
import os
import subprocess
import json


class NodeMonitorWorker(BaseWorker):

    def __init__(self, queue_name='nodemonitor_queue', host='localhost'):
        super(NodeMonitorWorker, self).__init__(queue_name, host)

    # def _create_supervisor(self, aggregator_name):
    #     filepath_name = os.path.join(settings.SUPERVISOR_CONFIG_PATH , aggregator_name )
    #     extrapath_runworker = os.path.join(settings.PROJECT_PATH , 'worker_runner.py')
    #     errorlog_path = os.path.join(settings.LOG_PATH , aggregator_name+'.err.log')
    #     outlog_path = os.path.join(settings.LOG_PATH , aggregator_name+'.out.log')
    #     file = open(filepath_name,"w")
    #     file.write('[program:'+aggregator_name+']\n')
    #     file.write('command=sh runenv.sh '+settings.PROJECT_ENV_PATH+' python '+extrapath_runworker+' aggregator '+aggregator_name+' localhost\n')
    #     file.write('directory='+settings.PROJECT_PATH+'\n')
    #     file.write('autostart=true\n')
    #     file.write('autorestart=true\n')
    #     file.write('numprocs=1\n')
    #     file.write('stderr_logfile='+errorlog_path+'\n')
    #     file.write('stderr_logfile='+outlog_path+'\n')
    #     file.close()

    # def _start_supervisor(self, program_name):
    #     pass
    #     # cmd = ['supervisorctl', 'reread']
    #     # p1 = subprocess.Popen(cmd, stdout=subprocess.PIPE).communicate()[0]
    #     # print p1
    #     # cmd = ['supervisorctl', 'start', program_name ]
    #     # p2 = subprocess.Popen(cmd, stdout=subprocess.PIPE).communicate()[0]
    #     # print p2

    # def _check_worker(self, program_name ):
    #     return True
    #     # if len(self._channel.consumer_tags) == 0:
    #     #     print "No Worker is listening to the queue"

    def Start_Worker(self, new_aggregator_name):
        # self._create_supervisor(new_aggregator_name)
        # self._start_supervisor(new_aggregator_name)
        aggr_worker = AW(queue_name=new_aggregator_name)
        aggr_worker.start()
        return True


    def callback(self, ch, method, properties, body):
        # Check if request is for Worker Creation
        # Call the worker create task.
        payload_data = json.loads(body)
        response = False
        if payload_data['worker-to-create'] == 'aggregator' :
            aggregator_name = payload_data['queue-to-bind']

            print " [.] Aggregate Name (%s)"  % (aggregator_name)
            response = self.Start_Worker(aggregator_name)
        else :
            # Message is to create or monitor worker in future
            pass

        # Check if aggregator worker is started
        if response:
            # Once Worker created Response to the reply to queue.
            ch.basic_publish(exchange='',
                             routing_key=properties.reply_to,
                             properties=pika.BasicProperties(correlation_id = \
                                                             properties.correlation_id),
                             body=str(response))
            ch.basic_ack(delivery_tag = method.delivery_tag)
        else :
            print "Error Not started Aggregator"

#---------------------------------------------
if __name__ == '__main__':
    worker_obj = NodeMonitorWorker()
    worker_obj.run()
