import sys
import argparse
from multiprocessing import Process

from route_worker import RouteWorker
from workflow_worker import WorkflowWorker
from pull_worker import PullWorker
from log_worker import LogWorker
from store_worker import StoreWorker

worker_types = {
				'workflow':WorkflowWorker,
				'route':RouteWorker,
				'pull':PullWorker,
				'log':LogWorker,
				'store':StoreWorker,
			   }

class WorkerRunner(object):
	def __init__(self, worker, count):
		'''
		Creates as many worker processes as the count
		'''
		print 'creating %s instances of %s'%(count, worker)
		for i in range(count):
			sub_proc = Process(target=worker)
			sub_proc.start()
			print 'started subprocess with pid:%s'%sub_proc.pid

#------------------------
if __name__ == '__main__':
	usage = """Usage: python worker_runner.py <workertype> <count> \n
	Different Types of workers: {}.""".format(','.join(worker_types.keys()))
	print usage
	parser = argparse.ArgumentParser()
	parser.add_argument('workertype', help='Enter the type of worker to start')
	parser.add_argument('count', help='Enter the number of the particular worker to start', type=int)
	args = parser.parse_args()
	count = args.count
	workerclass = worker_types.get(args.workertype)
	if not (workerclass and count):
		print 'Wrong input . Try Again. Either workertype %s did not match or the count is not acceptable' %args.workertype
		sys.exit()
	WorkerRunner(workerclass, count)




 