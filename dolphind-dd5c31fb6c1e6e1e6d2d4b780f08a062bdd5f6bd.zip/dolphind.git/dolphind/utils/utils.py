'''This file will contain all the necessary utilities for ECHO'''

import pika
import os
import re
import subprocess
import json
import uuid
import xlrd
from datetime import timedelta, datetime
from functools import update_wrapper
from dolphind.lib import mysql_connector as sql
from flask import request, current_app, make_response
from dolphind.lib.cassandra_connector import Cassandra_Connector as cql
from dolphind.config.config import script_loc, token_validity
import random

def generate_task_id():
    cql_obj = cql(key_space='dolphind')
    cql_obj.connect()
    rand = random.randint(1,200000)
    rows = cql_obj.select('task_details',[], {'id':rand})
    if not rows:
        return rand
    else:
        return generate_task_id()

def config_section_map(Config,section):
    dict1 = {}
    options = Config.options(section)
    for option in options:
        try:
            dict1[option] = Config.get(section, option)
            if dict1[option] == -1:
                DebugPrint("skip: %s" % option)
        except:
            print("exception on %s!" % option)
            dict1[option] = None
    return dict1

def crossdomain(origin=None, methods=None, headers=None,
                max_age=21600, attach_to_all=True,
                automatic_options=True):
    if methods is not None:
        methods = ', '.join(sorted(x.upper() for x in methods))
    if headers is not None and not isinstance(headers, basestring):
        headers = ', '.join(x.upper() for x in headers)
    if not isinstance(origin, basestring):
        origin = ', '.join(origin)
    if isinstance(max_age, timedelta):
        max_age = max_age.total_seconds()

    def get_methods():
        if methods is not None:
            return methods

        options_resp = current_app.make_default_options_response()
        return options_resp.headers['allow']

    def decorator(f):
        def wrapped_function(*args, **kwargs):
            if automatic_options and request.method == 'OPTIONS':
                resp = current_app.make_default_options_response()
            else:
                resp = make_response(f(*args, **kwargs))
            if not attach_to_all and request.method != 'OPTIONS':
                return resp

            h = resp.headers
            print origin
            h['Content-Type'] = '*'
            h['Access-Control-Allow-Origin'] = '*'
            h['Access-Control-Allow-Methods'] = get_methods()
            h['Access-Control-Max-Age'] = str(max_age)
            print 'the headers %s'%headers
            if headers is not None:
                h['Access-Control-Allow-Headers'] = headers
            else:
                h['Access-Control-Allow-Headers'] = 'Content-Type'
            return resp

        f.provide_automatic_options = False
        return update_wrapper(wrapped_function, f)
    return decorator


def is_running(process):
    '''checks if a process is running and returns True if it is else False'''
    all_proc = subprocess.Popen(["ps", "axw"],stdout=subprocess.PIPE)
    ps_status={i:'not running' for i in process}
    if type(process) is str:
        for x in all_proc.stdout:
            if re.search(process, x):
                return True
        return False
    elif type(process) is list:
        for ps in process:
            for x in all_proc.stdout:
                if re.search(ps, x):
                    ps_status[ps] = 'running'
        return ps_status

def system_start_or_stop(process, switch='start'):
    '''
    @args: process:: is a string.
          switch:: either start or stop. Based on which we will either start or stop the process
    '''
    try:
        if process not in script_loc.keys():
            return 'unrecognized process'
        if switch == 'start':
            if not is_running(process):
                subprocess.Popen([script_loc[process],switch], stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                #os.system(script_loc[process]+' '+switch)
        elif switch == 'stop':
            if is_running(process):
                subprocess.Popen([script_loc[process],switch], stdout=subprocess.PIPE,stderr=subprocess.PIPE)
                #os.system(script_loc[process]+' '+switch)
        else:
            return 'unknown switch'
    except:
        print 'error'

def generate_store_token(username):
	con_obj = sql.get_connection()
	token = uuid.uuid4().hex
	now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
	values = [(token, username, now),]
	con_obj.insert('tokens', values=values)
	return token, now

def authenticate(username, token):
    '''
    check if the user is present in the users table. 
        - If present then chek if the token is not expired
            - If token not expired then just return True
            - else delete the token entry in the tokens table and generate new token and return the same 
        - else
            just return false
    '''
    pass

def is_valid_token(token):
	con_obj = sql.get_connection()
	result = con_obj.select('tokens', what=[], where={'token':token})
	return json.dumps({'valid':True}) if result else json.dumps({'valid':False})

def get_row_list_from_xlfile(file_path,file_name):
    ''' load the excel file read the content and returns the row list in dict format'''
    file_loc=os.path.join(file_path,file_name)
    try:        
        wb = xlrd.open_workbook(file_loc)
        ws = wb.sheet_by_name('Sheet1')
        hd_row = 0
        hd_info = [str(ws.cell_value(hd_row, i)) for i in xrange(ws.ncols)]
        row_dict_list = []
        for row in xrange(hd_row+1, ws.nrows):
            row_dict = {}
            for col in xrange(ws.ncols):
                cell_type = ws.cell_type(row, col)
                if cell_type == xlrd.XL_CELL_EMPTY:
                    value = None
                elif cell_type == xlrd.XL_CELL_TEXT:
                    value = str(ws.cell_value(row, col))
                elif cell_type == xlrd.XL_CELL_NUMBER:
                    value = int(ws.cell_value(row,col))
                else:
                    value = ws.cell_value(row, col)
                row_dict[hd_info[col]] = value
                row_dict_list.append(row_dict)

        return row_dict_list
    except:
        print "Error in loading and reading the excel file"
        return None

def insert_data_cassandra(table, data):
    try:
        cql_obj = cql(key_space='dolphind')
        cql_obj.connect()
        cql_obj.insert(table,data)
        return True
    except:
        print "Error in inserting data"
        return False


def new_channel():
        connection = pika.BlockingConnection(
                              pika.ConnectionParameters(host='localhost')
                     )
        channel = connection.channel()
        return channel

if __name__ == '__main__':
    # print is_running('rabbitmq')
    # system_start_or_stop('rabbitmq', 'start')
    # print is_running('rabbitmq')
    print generate_store_token('dinesh')
    print generate_task_id()


