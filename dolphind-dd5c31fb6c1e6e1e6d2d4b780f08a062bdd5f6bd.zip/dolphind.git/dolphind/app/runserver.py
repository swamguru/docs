from dolphind.app import app, socketio
app.run(host='0.0.0.0', port=9009, debug=True)
#socketio.run(app, host='0.0.0.0', port=9009)

