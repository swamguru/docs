import pika
import json
import os
import datetime
import yaml
from flask import Flask, flash, session, request, render_template, redirect, url_for, jsonify
from flask.ext.login import login_required
from dolphind.app import app, socketio
from dolphind.lib import mysql_connector as sql
from dolphind.lib.cassandra_connector import Cassandra_Connector as cql
from dolphind.config.config import connection_params_mysql as conn_param
from dolphind.config import config
# from gevent import monkey
#monkey.patch_all()
from werkzeug import secure_filename
import time

from flask.ext.socketio import SocketIO, emit
from threading import Thread
from dolphind.utils.utils import is_running, generate_store_token, crossdomain, \
get_row_list_from_xlfile, insert_data_cassandra, generate_task_id
thread = None
file_path ='/var/www/uploads'

def allowed_file(filename):
    ''' For a given file, return whether it's an allowed type or not for storing'''
    return '.' in filename and \
           filename.rsplit('.', 1)[1] in set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'xls','xlsx'])


def get_user(user, pasw):
	con_obj = sql.Mysql_Connector()
	con_obj.connect(**conn_param)
	result = con_obj.select('users', what=[], where={'username':str(user), 'password':str(pasw)})
	if result:
		return result[0]['id']
	else:
		return None

@app.route('/')
@crossdomain(origin='*')
def index():
    return 'Hello World. This is ECHO 1.0'


@app.route('/home.html', methods=['GET', 'POST'])
@crossdomain(origin='*')
def home():
	return render_template('home.html')


@app.route('/logout.html')
@login_required
@crossdomain(origin='*')
def logout():
	login.logout_user()
	return redirect('/login.html', code=302)


@app.route('/login', methods=['GET', 'POST', 'OPTIONS'])
@crossdomain(origin='*')
def login():
    request_dict = request.get_json()

    username = request_dict.get('username')
    password = request_dict.get('password')
    if username == 'admin' and password == 'admin':
        token, now = generate_store_token(str(username))
        return json.dumps({'auth_token':token, 'created_on':now})
    else:
        return json.dumps({'error':'user credentials invalid'})

def create_msg(file_path=None,body=None,task_name=None):
    'It takes the file path and create a msg that will be posted to request worker'
    final_msg = {}
    msg_header = {}
    msg_body = {}
    msg_header['task-id'] = generate_task_id()
    msg_header['task-name'] = 'd1_server_info'
    msg_header['task-submitted-date_time'] = str(datetime.datetime.now())
    if file_path == None:
        msg_body = json.loads(body)
        msg_header['task-name'] = task_name
    else:
        msg_body['file-data'] = file_path
        msg_body['file-type'] = 'xlsx'
    final_msg["msg-header"] = [msg_header]
    final_msg["msg-body"] = [msg_body]
    return final_msg

def send_to_request_worker(msg):
    try:
        connection = pika.BlockingConnection(
                                  pika.ConnectionParameters(host='localhost')
                         )
        channel = connection.channel()
        channel.basic_publish(exchange= '',
                                routing_key='requestmanager_queue',
                                body=json.dumps(msg),
                                properties=pika.BasicProperties(
                                    delivery_mode = 2,))
        channel.close()
    except:
        print traceback.format_exc()
    return

@app.route('/file_upload', methods=['POST', 'OPTIONS'])
@crossdomain(origin='*')
def file_upload():
    file = request.files['file']
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        server_file_path = os.path.join(file_path, filename)
        file.save(server_file_path)
        request_msg = create_msg(file_path=server_file_path)
        send_to_request_worker(request_msg)
        #return the status url
        return jsonify({'result':'file uploaded.'})

@app.route('/push/<string:server>', methods=['POST', 'OPTIONS'])
@crossdomain(origin='*')
def push_start(server):
    data = request.data
    request_msg = create_msg(body=data,task_name=server)
    send_to_request_worker(request_msg)
        #return the status url
    status_url = 'http://10.180.112.240:9002/task_status/' + str(request_msg['msg-header'][0]['task-id'])
    #print str(request_msg['msg-header']['task-id'])
    return jsonify({'result':'Message Pushed to Dolphind.', 'status-url': status_url})

@app.route('/workflow_upload', methods=['POST', 'OPTIONS'])
@crossdomain(origin='*')
def workflow_upload():
    '''For json string payloads we need to set  "Content-Type" header to application/json
       For xls it can be any other things
    '''
    dt = datetime.datetime.now().replace(microsecond=0)
    if not request.files:#request.mimetype == 'application/json':
        data = request.get_data()
        rows = yaml.load(data)
 
    else: #This is for xls data
        file = request.files['file']
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file.save(os.path.join(file_path, filename))
            rows=get_row_list_from_xlfile(file_path, filename)
 
    for i in rows:
        i['subm_time'] = dt
        wc = i['workflow_config']
        i['workflow_config'] = wc if wc is str else str(wc)
 
    if insert_data_cassandra(config.wf_table, rows):
        return jsonify({'result':'file uploaded and data inserted into cassandra table'})
    else:
        return jsonify({'result':'file uploaded but error in inserting data to cassandra'})


'''
@app.route('/workflow_upload', methods=['POST', 'OPTIONS'])
@crossdomain(origin='*')
def workflow_upload():
    file = request.files['file']
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file.save(os.path.join(file_path, filename))

        rows=get_row_list_from_xlfile(file_path, filename)
        dt = datetime.datetime.now().replace(microsecond=0)
        for i in rows:
            i['subm_time'] = dt
        if insert_data_cassandra(config.wf_table, rows):
            return jsonify({'result':'file uploaded and data inserted into cassandra table'})
        else:
            return jsonify({'result':'file uploaded but error in inserting data to cassandra'})
'''

@app.route('/retry', methods=['GET', 'OPTIONS'])
@crossdomain(origin='*')
def retry():
    con_obj = cql(key_space='dolphind')
    con_obj.connect()
    result = con_obj.select('sub_task_details', ['id','error', 'status', 'task_id'], {'status':'ER'})
    return jsonify({'result':result})


@app.route('/task_details', methods=['GET', 'OPTIONS'])
@crossdomain(origin='*')
def task_details(task_id=None):
    con_obj = cql(key_space='dolphind')
    con_obj.connect()
    result = con_obj.select('task_details', ['id',  'status', 'name'], {})
    #result = con_obj.select('task_details', ['id',  'status', 'name'], {'id':int(task_id)})
    return jsonify({'result':result})

@app.route('/task_status/<int:task_id>', methods=['GET', 'OPTIONS'])
@crossdomain(origin='*')
def task_single_status(task_id):
    con_obj = cql(key_space='dolphind')
    con_obj.connect()
    # result = con_obj.select('task_details', ['id',  'status', 'name'], {})
    result = con_obj.select('task_details', ['id',  'status', 'name', 'reply'], {'id':int(task_id)})
    return jsonify({'result':result})

@app.route('/is_valid/<string:token>', methods=['GET'])
@crossdomain(origin='*')
def validate_token(token):
    return is_valid_token(token)

#-------------------------------------
#for system status websocket

def system_status():
    status ={}
    apps =['rabbitmq','mysql','cassandra']
    for p in apps:
        if is_running(p):
            status[p] = 'Running'
        else:
            status[p] = 'Not Running'
    return status


def background_thread(source):
    """Example of how to send server generated events to clients."""
    count = 0
    while True:
        time.sleep(5)
        count += 1
        #rows ={'rabbitmq':'Running','cassandra':'running', 'mysql': 'Running'}
        print 'inside system'
        rows = system_status()
        rows['task_request_id']=100;
        rows['task_name']='pull_server_info'
        rows['task_status']='completed'
        #rows = {'task_request_id':100, 'task_name':'pull_server_info', 'task_status':'completed'}
        socketio.emit('my response',
                  {'data': json.dumps(rows)},
                  namespace='/test')

@app.route('/system_status.html', methods=['GET'])
def sys_status():
    global thread
    if thread is None:
        thread = Thread(target=background_thread, args=('system',))
        thread.start()
    return render_template('system_status.html')

@app.route('/task_status.html', methods=['GET'])
def task_status():
    global thread
    if thread is None:
        thread = Thread(target=background_thread, args=('task',))
        thread.start()
    return render_template('task_status.html')


@socketio.on('task event', namespace='/test')
def task_stat_message(message):
    rows ={'task_request_id':100, 'task_status':'completed'}
    emit('my response',
         {'data': json.dumps(rows)},
         broadcast=True)
















