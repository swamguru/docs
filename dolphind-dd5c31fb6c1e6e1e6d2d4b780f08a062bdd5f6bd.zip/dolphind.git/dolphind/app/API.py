#!/usr/bin/env python
import pika
import sys
import json
from flask import Flask, jsonify
import logging

from gevent import monkey
monkey.patch_all()
import time
from flask import Flask, render_template, session, request,jsonify
from flask.ext.socketio import SocketIO, emit, join_room, leave_room, \
    close_room, disconnect

from threading import Thread
from util import is_running


app = Flask(__name__)
app.debug = True
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)
thread = None


# logging.basicConfig(format='%(levelname)s:%(message)s', level=logging.CRITICAL)

connection = pika.BlockingConnection(pika.ConnectionParameters(
        host='localhost'))
channel = connection.channel()
channe2 = connection.channel()
channe3 = connection.channel()


channel.queue_declare(queue='workflowmanager_queue', durable=True)
channe2.queue_declare(queue='routemanager_queue', durable=True)
channe3.queue_declare(queue='storemanager_queue', durable=True)

task_id = 99
pika_property = pika.BasicProperties( delivery_mode = 2, )


def workflow_message(tk_id,server_info):
    message = {}
    message['task-request-id'] = str(tk_id)
    message['pull-request-id'] = server_info #'dl_server_info'
    return json.dumps(message)

def system_status():
    status ={}
    apps =['rabbitmq','mysql','cassandra','sreenivas']
    for p in apps:
        if is_running(p):
            status[p] = 'running'
        else:
            status[p] = 'not running'
    
    return status


@app.route('/pull/<string:server>', methods=['GET'])
def pull_start(server):
    global task_id
    connection = pika.BlockingConnection(pika.ConnectionParameters(
        host='localhost'))
    channel = connection.channel()
    pika_property = pika.BasicProperties( delivery_mode = 2, )
    task_id = task_id + 1
    message = workflow_message(task_id,server)

    channel.basic_publish(exchange='',
                          routing_key='workflowmanager_queue',
                          body=message,
                          properties=pika_property
                         )
    print " Rest APi Push to Workflow Manager Queue , Data :: [x] Sent %r" % (message,)
    connection.close()
    return jsonify({'result' : 'Started Echo Process '+str(task_id)})

@app.route('/', methods=['GET'])
def pull_server():
    return "Hello World!"

@app.route('/task/<int:request_id>', methods=['GET'])
def task_status(request_id):
    from cassandra.cluster import Cluster
    sclst=Cluster()
    ss=sclst.connect()
    ss.execute("USE guna")
    rows=ss.execute("SELECT task_status from taskstatus where task_request_id ="+str(request_id))
    if len(rows) == 1 :
        return jsonify({'task_status' : rows[0].task_status, 'task_id' : request_id})
    else:
        return jsonify({'task_status' : 'Not Avaliable', 'task_id' : request_id})


def background_thread():
    """Example of how to send server generated events to clients."""
    count = 0
    while True:
        time.sleep(10)
        count += 1
        print "While Loop Update scoket"
        # rows ={'RabitMQ':'Running','Cassandra DB':'running', 'MySql': 'Running','Route_worker':'up'}
        rows=system_status()
        socketio.emit('my response',
                      {'data': json.dumps(rows)},
                      namespace='/test')

@app.route('/system_status', methods=['GET'])
def index():
    global thread
    if thread is None:
        thread = Thread(target=background_thread)
        thread.start()        
    return render_template('index_old.html')

@socketio.on('system event', namespace='/test')
def test_systemstat_message(message):   
    # rows ={'RabitMQ':'Running','Cassandra DB':'running', 'MySql': 'Running','Route_worker':'up'}
    rows=system_status()
    emit('my response',
         {'data': json.dumps(rows)},
         broadcast=True)


if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0')
