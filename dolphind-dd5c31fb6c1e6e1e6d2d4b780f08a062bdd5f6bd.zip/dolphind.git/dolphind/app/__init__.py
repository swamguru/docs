from flask import Flask
from flask.ext.login import LoginManager
from flask.ext.socketio import SocketIO
from werkzeug.debug import DebuggedApplication


app = Flask(__name__)
login_manager = LoginManager()
login_manager.init_app(app)
app.wsgi_app = DebuggedApplication(app.wsgi_app, True)
app.config['SECRET_KEY'] = 'secret!'
app.config['debug'] = True
socketio = SocketIO(app)
import dolphind.app.views
