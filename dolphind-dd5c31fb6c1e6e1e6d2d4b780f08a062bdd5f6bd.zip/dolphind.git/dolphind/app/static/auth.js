<script>
            $( document ).ready(function() {
                if (!window.sessionStorage.token) {
                window.location = 'http://firstdata.in/login.html';
              }

            });
</script>