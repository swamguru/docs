import unittest
from dbconnectors.mysql_connector import Mysql_Connector as mysql

class mysqlquerytests(unittest.TestCase):

    def setUp(self):
        my_sql = mysql()
        my_sql.connect(host='localhost',username='root',pwd='root',db='echo')
        self.my_sql = my_sql

    def test_insert(self):
        self.my_sql.insert('student', [(11, 'dinesh', 'kumar', 24, 'EEE'),(12, 'manikandan', 'kumaraguru', 54, 'CSE')])
        result =self.my_sql.select('student',[], {'id':12})
        self.assertEqual(result,True)
    
    def test_update(self):
        self.my_sql.update('student', {'last_name':'madan'}, {'first_name':'manikandan'})
        result =self.my_sql.select('student',[], {'id':12})
        self.assertEqual(result,True)

    def test_delete(self):
        result =self.my_sql.delete('student',{'first_name':'manikandan'})
        self.assertEqual(result,True)    

    def test_select(self):
        self.my_sql.insert('student', [(12, 'manikandan', 'kumaraguru', 54, 'CSE')])
        result =self.my_sql.select('student',[], {'id':12})
        self.assertEqual(result,True)    


if __name__ == '__main__':
    unittest.main()