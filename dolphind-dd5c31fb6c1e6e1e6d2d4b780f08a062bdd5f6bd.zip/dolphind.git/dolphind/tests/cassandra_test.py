import unittest
from dbconnectors.cassandra_connector import Cassandra_Connector

class cassandraquerytests(unittest.TestCase):

    def setUp(self):
        casandra = Cassandra_Connector(key_space='guna')
        casandra.connect()
        self.casandra = casandra

    def test_insert(self):
        self.casandra.insert('taskstatus',[{'task_request_id':133,'task_request_data':'sreenivas data','task_status':'closed'}])  
        result =self.casandra.select('taskstatus',[], {'task_request_id':133})
        self.assertEqual(result,True)
    
    def test_update(self):
        self.casandra.update('taskstatus', {'task_request_data':'json data finished'}, {'task_request_id':133})
        result =self.casandra.select('taskstatus',[], {'task_request_id':133})
        self.assertEqual(result,True)

    def test_delete(self):
        result =self.casandra.delete('taskstatus',{'task_request_id':133})
        self.assertEqual(result,True)

    def test_select(self):
        self.casandra.insert('taskstatus',[{'task_request_id':133,'task_request_data':'sreenivas data','task_status':'closed'}])
        result =self.casandra.select('taskstatus',[], {'task_request_id':133})
        self.assertEqual(result,True)

    def test_create(self):
        cols_task_pay = {'TASK_ID':'int','TASK_PAYLOAD':'blob','TASK_STATUS':'varchar','SUBMITTED_TIME':'timestamp','TASK_ERROR':'varchar'}
        result=self.casandra.create('TASK_DETAILS',cols=cols_task_pay,pkey=['TASK_ID'])
        self.assertEqual(result,True)    

    def tearDown(self):
        self.casandra.close()


if __name__ == '__main__':
    unittest.main()