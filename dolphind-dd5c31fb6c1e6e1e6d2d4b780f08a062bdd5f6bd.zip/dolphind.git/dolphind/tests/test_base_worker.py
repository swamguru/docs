"""
Tests for echo.base_worker.BaseWorker
"""
try:
    import unittest2 as unittest
except ImportError:
    import unittest

from echo.lib import base_worker

class BaseWorkerTests(unittest.TestCase):
    base_worker.BaseWorker()
    pass
