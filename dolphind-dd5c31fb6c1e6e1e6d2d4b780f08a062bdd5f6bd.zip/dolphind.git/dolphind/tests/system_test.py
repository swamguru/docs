import unittest
from utils import is_running,system_start_or_stop

class systemhealthtests(unittest.TestCase):

    def setUp(self):
        pass

    def test_running_str(self):
        result=is_running('cassandra')
        self.assertEqual(result,True)
    
   def test_running_list(self):
        result=is_running(['cassandra','mysql'])
        self.assertEqual(result,{'cassandra':'running','mysql':'running'}})

    def test_system_stop(self):
        system_start_or_stop('cassandra','stop')
        result=is_running('cassandra')
        self.assertEqual(result,False)

     def test_system_stop(self):
        system_start_or_stop('cassandra','start')
        result=is_running('cassandra')
        self.assertEqual(result,True)

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()