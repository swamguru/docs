use echo;
create table if not exists users(id int primary key, username varchar(200), password varchar(100), first_name varchar(100), last_name varchar(100), email varchar(200), is_active tinyint(1), is_admin tinyint(1));
insert into users values (1, 'admin', 'admin', 'admin', 'admin', 'admin@firstdata.com', 1,1);
create table if not exists tokens(tokens varchar(100) primary key, username varchar(100), created_on datetime);
