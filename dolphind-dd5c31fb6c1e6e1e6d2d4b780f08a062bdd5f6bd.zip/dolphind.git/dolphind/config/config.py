'''Provides all the necessary configurations for ECHO'''

max_retries = 3

connection_params_mysql = {
						'host': 'localhost', 
						'username':'root',
						'pwd':'root',
						'db':'DolphinD',
					}
connection_params_cassandra = {
						'nodes': [], 
						'username':'root',
						'pwd':'root',
						'key_space':'dolphind',
					}

msg_header = {
				"task-id": None,
				"sub-task-id": 0,
				"task-name": None,
				"from-worker": None,
				"aggregator-reply-to-queue" : "None",
				"total-sub-tasks" : "None",
				"error-msg": "None",
				"re-try": "None",
				"re-try-cnt": str(max_retries),
				"ok" : "True"
			}


token_validity =  60 #minutes which is 1 hour
script_loc = {
				'cassandra' : '/etc/init.d/cassandra',
				'mysql' : '/etc/init.d/mysql',
				'rabbitmq' : '/etc/init.d/rabbitmq-server',
				'nginx' : '/etc/init.d/nginx',
			}

wf_table = 'workflow_config'


