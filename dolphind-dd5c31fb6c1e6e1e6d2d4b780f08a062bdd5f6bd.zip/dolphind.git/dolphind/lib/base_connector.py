'''Generic Connectors for python'''
from abc import ABCMeta, abstractmethod

form_columns = lambda what: '*' if not what else ', '.join(what)

class ConditionMissingException(Exception):
    pass

def form_conditions(where, set=False):
    if not where:
        return ''
    elif len(where) == 1:
        return ['%s = %d'%(i,j)  if type(j) is int else '{!s} = {!r}'.format(i,j) for i,j in where.iteritems()][0]
    else:
        if set:
            return ','.join(['%s = %d'%(i,j)  if type(j) is int else '{!s} = {!r}'.format(i,j) for i,j in where.iteritems()])
        return ' and '.join(['%s = %d'%(i,j)  if type(j) is int else '{!s} = {!r}'.format(i,j) for i,j in where.iteritems()])

def format_result(cursor):
        table_columns = cursor.description
        result = [{table_columns[index][0]:column for index, column in enumerate(value)} \
        for value in cursor.fetchall()]
        return result

def form_inserts(row_list):
        row_str = '('
        value_str = '('
        for items in row_list:
            row_str = row_str + items + ','
            value_str = value_str + '?,'

        row_str = row_str.rstrip(',')
        value_str = value_str.rstrip(',')
        row_str = row_str + ')'
        value_str = value_str + ')'
        return row_str,value_str


class Generic_Connector(object):
    __metaclass__ = ABCMeta

    @abstractmethod
    def connect(**conn_params):
        pass

    @abstractmethod
    def select(self, table, what, where, **kwargs):
        pass

    @abstractmethod
    def update(self, table, set, where, **kwargs):
        pass

    # @abstractmethod
    # def insert(self, table, values, **kwargs):
    #   pass

    @abstractmethod
    def delete(self, table, what, **kwargs):
        pass

    # @abstractmethod
    # def close():
    #   pass



