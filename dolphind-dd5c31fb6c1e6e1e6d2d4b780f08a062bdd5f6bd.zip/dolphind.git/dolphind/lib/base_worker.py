import multiprocessing
import pika
import time
from abc import ABCMeta, abstractmethod

class BaseWorker(multiprocessing.Process):
    """
    worker process that waits infinitly for task msgs and calls
    the `callback` whenever it gets a msg
    Base class for all the workers to extend
    """
    __metaclass__ = ABCMeta

    def __init__(self, queue, host='localhost'):
        multiprocessing.Process.__init__(self)
        self.stop_working = multiprocessing.Event()
        self.queue = queue

    def run(self):
        """
        worker method, open a channel through a pika connection and
        start consuming
        Generic initialization for all worker classes
        """
        connection = pika.BlockingConnection(
                              pika.ConnectionParameters(host='localhost')
                     )
        channel = connection.channel()
        channel.queue_declare(queue=self.queue, auto_delete=False,
                                                    durable=True)
        print ' %s :: [*] Waiting for messages. To exit press CTRL+C'%(self.queue)

        # don't give work to one worker guy until he's finished
        channel.basic_qos(prefetch_count=1)
        channel.basic_consume(self.callback, queue=self.queue)

        # do what `channel.start_consuming()` does but with stopping signal
        while len(channel._consumers) and not self.stop_working.is_set():
            channel.connection.process_data_events()

        channel.stop_consuming()
        connection.close()
        return 0

    def signal_exit(self):
        """exit when finished with current loop"""
        self.stop_working.set()

    def exit(self):
        """exit worker, blocks until worker is finished and dead"""
        self.signal_exit()
        while self.is_alive(): # checking `is_alive()` on zombies kills them
            time.sleep(1)

    def kill(self):
        """kill now! should not use this, might create problems"""
        self.terminate()
        self.join()

    @abstractmethod
    def callback(channel, method, properties, body):
        """pika basic consume callback"""
        print 'GOT:', body
        # result = save_to_database(body)
        #print 'DONE:', result
        channel.basic_ack(delivery_tag=method.delivery_tag)
