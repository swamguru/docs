import MySQLdb as sql
from base_connector import *
from dolphind.config.config import connection_params_mysql

class Mysql_Connector(Generic_Connector):

	def connect(self, **conn_param):
		self.host = conn_param.get('host')
		self.username = conn_param.get('username')
		self.pwd = conn_param.get('pwd')
		self.db = conn_param.get('db')
		self.connection = sql.connect(self.host, self.username, self.pwd, self.db)
		self.cursor = self.connection.cursor()


	def select(self, table, what=[], where={}):
		try:
			columns = form_columns(what)
			conditions = form_conditions(where)
			query = "select {columns} from {table} ".format(columns=columns, table=table)
			if conditions:
				query = query + 'where {where}'.format(where=conditions)
			self.cursor.execute(query)
			result = format_result(self.cursor)
			print result
		except Exception as e:
			print 'Exception in select %s'%e


	def update(self, table, set={}, where={}):
		if not where:
				raise ConditionMissingException
		try:
			sett = form_conditions(set, set=True)
			conditions = form_conditions(where)
			query = "update {table} set {set} where {where}".format(table=table, set=sett, where=conditions)
			print query
			self.cursor.execute(query)
			self.connection.commit()
		except Exception as e:
			print 'Exception in update %s'%e

	def delete(self, table, where={}):
		if not where:
				raise ConditionMissingException
		try:
			conditions = form_conditions(where)
			query = "delete from {table} where {where}".format(table=table, where=conditions)
			self.cursor.execute(query)
			self.connection.commit()
		except  Exception as e:
			print 'Exception in delete %s'%e

	def insert(self, table, values=[]):
	 	'''values should be list of tuples and the length should match the no. of columns'''
	 	if not values:
	 		return 'Nothing to insert'
	 	try:
			values = [str(i) for i in values]
	 		query = 'insert into {table} values '.format(table=table)
	 		print query
	 		for i in values:
	 			self.cursor.execute(query+i)
	 		self.connection.commit()
	 	except Exception as e:
	 		print 'Exception in insert %s'%e

def get_connection():
	'returns a coonnection object'
	con_obj = Mysql_Connector()
	con_obj.connect(**connection_params_mysql)
	return con_obj



if __name__ == '__main__':
	con_obj = Mysql_Connector()
	con_obj.connect(host='localhost',username='root',pwd='root',db='test')
	con_obj.select('student',[], {'id':3})
	con_obj.update('student', {'last_name':'kumaraguru'}, {'first_name':'manikandan'})
	con_obj.delete('student',{'first_name':'rajesh'})
	con_obj.insert('student', [(11, 'naaaaiyandi', 'narrrrryagan', 24, 'EEE'),
		(12, 'parama', 'veeran', 54, 'ECE')])
	con_obj.select('student')
