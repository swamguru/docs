'''
Generic class for the msg put in queue. In the future if we want to apply some processing to the received 
message, having a separate msg class will be useful.
'''
import yaml
from dolphind.config.config import msg_header

class Msg(object):
	def __init__(self, payload):
		payload_data = yaml.load(payload)
		self.header_data = payload_data['msg-header'][0]
		self.body = payload_data['msg-body']
		self.task_id = self.header_data.get('task-id')
		self.task_name = self.header_data.get('task-name')
		self.msg_from = self.header_data.get('from-worker')



