from cassandra.cluster import Cluster
from cassandra.query import dict_factory
from base_connector import *
# from __init__ import *


class Cassandra_Connector(Generic_Connector):

	def __init__(self, **conn_param):
		self.clstr = Cluster()
		# self.host = conn_param.get('host')
		# self.username = conn_param.get('username')
		# self.pwd = conn_param.get('pwd')
		self.key_space = conn_param.get('key_space')

	def connect(self):
		#self.session = self.clstr.connect(self.host, self.username, self.pwd, self.key_space)
		self.session = self.clstr.connect()
		try:
			self.session.execute("USE "+self.key_space)
			self.session.row_factory=dict_factory
			return self.session
		except Exception as e:
			print 'Exception in using keyspace %s'%e

	def select(self, table, what=[], where={}):
		try:
			columns = form_columns(what)
			conditions = form_conditions(where)
			query = "select {columns} from {table} ".format(columns=columns, table=table)
			if conditions:
				query = query + 'where {where}'.format(where=conditions)
			print query
			rows = self.session.execute(query)
			return rows
		except Exception as e:
			print 'Exception in select %s'%e

	def update(self, table, set={}, where={}):
		if not where:
				raise ConditionMissingException
		try:
			sett = form_conditions(set, set=True)
			conditions = form_conditions(where)
			query = "update {table} set {set} where {where}".format(table=table, set=sett, where=conditions)
			#print 'the query RRRRRRRRRRRRRr %s' %query
			self.session.execute(query)
		except Exception as e:
			print 'Exception in update %s'%e

	def delete(self, table, where={}):
		if not where:
				raise ConditionMissingException
		try:
			conditions = form_conditions(where)
			query = "delete from {table} where {where}".format(table=table, where=conditions)
			self.session.execute(query)
		except  Exception as e:
			print 'Exception in delete %s'%e

	def insert(self, table, values=[]):
	 	'''values should be list of dictionaries and the length of dictionary should match the no. of columns'''
	 	if not values:
	 		return 'Nothing to insert'
	 	try:
	 		for item in values:
	 			columns,val_str=form_inserts(item.keys())
	 			vals=item.values()
	 			query = self.session.prepare('insert into {table} {columns} values {val_str}'.format(table=table,columns=columns,val_str=val_str))
	 			stm=self.session.execute(query.bind(vals))
	 	except Exception as e:
	 		print 'Exception in insert %s'%e


	def _close(self):
		self.session.shutdown()
		self.clstr.shutdown()
		print 'connection closed'


# if __name__ == '__main__':
# 	con_obj = Cassandra_Connector(key_space='guna')
# 	con_obj.connect()
# 	con_obj.select('taskstatus',[],{})
	# con_obj.insert('taskstatus',[{'task_request_id':133,'task_request_data':'saravanan','task_status':'closed'},
	# 	                         {'task_request_id':900,'task_request_data':'dinesh','task_status':'finsished'},
	# 	                         {'task_request_id':700,'task_request_data':'puvvala','task_status':'InProgress'}])
	# con_obj.select('taskstatus',[], {'task_request_id':100})
	# con_obj.update('taskstatus', {'task_request_data':'json data finished'}, {'task_request_id':100})
	# con_obj.delete('taskstatus',{'task_request_id':100})
