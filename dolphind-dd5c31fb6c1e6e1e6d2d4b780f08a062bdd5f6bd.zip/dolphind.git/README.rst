=================================
 DFramwork - Echo
=================================

.. image:: https://d3v2y4zgl9ajcu.cloudfront.net/etc/designs/firstdatacomDesign/firstdatacom-responsive/libs/firstdata-responsive-headlibs/img/fd-full-logo.svg

|build-status| |coverage-status|

:Version: 1.2 (d2)
:Web: https://www.firstdata.com/en_us/home.html

--

What is a DFramework?
=====================

Task queues are used as a mechanism to distribute work across threads or
machines.



What do I need?
===============

DFramwork version 1.2 runs on,

- Python (2.6)


.. _DFramework-documentation:

Documentation
=============

The `latest documentation`_ with user guides, tutorials and API reference
is hosted at Read The Docs.

.. _`latest documentation`: http://docs.DFrameworkproject.org/en/latest/

.. _DFramework-installation:

Installation
============

You can install DFramework either via the Python Package Index (PyPI)
or from source.

To install using `pip`,::

    $ pip install -U

To install using `easy_install`,::

    $ easy_install -U DFramework

.. _bundles:



