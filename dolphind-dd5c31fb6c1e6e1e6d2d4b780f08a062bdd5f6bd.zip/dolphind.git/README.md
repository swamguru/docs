1. Start the Virtual env
	source /opt/dolphind/venv/bin/activate
        or
        startenv

2. Set Python enviorment

	export PYTHONPATH=/home/dolphind_deploy_ready/dolphind/
	or
        pypath

3. Using SupervisorD start following
	Supervisord is already running. To restart goto supervisorctl and give command
	"restart all"

4. supervisord webconsole
	http://10.180.112.240:9001/
        user : user
	password : 123

5. start the rest API:
	python /home/dolphind_deploy_ready/dolphind/dolphind/app/runserver.py
	or
	startrest

6. start the Echo UI:
	cd /home/dolphind_deploy_ready/Echo_UI
	/root/.npm-packages/bin/grunt serve
	or
	startui

7. Goto http://10.180.112.240:9000/
	login:admin:admin

8. workflow upload page will open:
	upload the attached workflow_config.xlsx

9. click on the upload link in the sidebar:
	upload the attached sample_data.xlsx

10. To check if the route worker is receiving and processing:
	tail -f /etc/dolphind/logs/poc.log

11.To check if the workflow is complete goto cassandra by typing cqlsh 
	select * from dolphind.task_details;
	select * from dolphind.sub_task_details; 
	
12.Check also if the required entries are created in Mysql db:
	type 'mysql' in prompt and give password as root
	select * from DolphinD.EMPLOYEE_DETAILS;


# supervisor command to update config
supervisorctl reread
supervisorctl update

$ supervisorctl stop nodebook
$ supervisorctl start nodebook

# how to restart rabbitmq
/usr/lib/rabbitmq/lib/rabbitmq_server-3.1.5/sbin/rabbitmq-server

#open sublime editor
/root/sublime_text_3/sublime_text
