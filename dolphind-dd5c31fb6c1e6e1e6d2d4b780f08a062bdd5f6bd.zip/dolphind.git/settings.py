import os


DEBUG = True
TEMPLATE_DEBUG = DEBUG


BASE_PATH = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT_PATH = os.path.join(BASE_PATH , 'dolphind')
SUPERVISOR_CONFIG_PATH = os.path.join(PROJECT_PATH, 'config')
LOG_PATH = os.path.join(PROJECT_PATH, 'logs')
PROJECT_ENV_PATH = os.path.join(PROJECT_PATH, 'venvdolphind')
