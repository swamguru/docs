#!/usr/bin/env python
# *- coding: utf-8 -*-
from dolphind.lib.base_worker import BaseWorker
import pika
import json
# Aggregate worker listens to aggregate_queue and process all messages.
# Processing logic is,
#   1) Increment sub-task-count variable
#   2) Publish payload to Route Queue if aggregateworker's sub-task-count == payload's total-sub-tasks-count.
#       i.e all sub-tasks are completed.
class AggregateWorker(BaseWorker):

    def __init__(self, queue_name='aggregate_queue', host='localhost'):
        self.queue_name = queue_name
        super(AggregateWorker, self).__init__(queue_name, host)
        # instance variable sub-task-count for counting the number of sub-tasks received
        self.sub_task_count = 0


    def callback(self, ch, method, properties, body):

        # Since this aggregate worker is specifically for this task, just increment the count whenever new message comes
        self.sub_task_count += 1

        # Check whether sub-task-count matches with the header payload's total-sub-tasks.
        # If matches(i.e all sub-tasks for this task are completed), publish the payload to RouteQueue.
        payload_data = {}
        payload_data = json.loads(body)
        header_data = payload_data['msg-header'][0]
        print "Reading Payload :: "+str(header_data)
        print "self.sub_task_count :: "+str(self.sub_task_count)

        data = {}
        if (int(self.sub_task_count) == int(header_data['total-sub-tasks'])):
            print "Reading Payload :: "+str(header_data)
            data['task-id'] = header_data['task-id']
            data['sub-task-id'] = header_data['sub-task-id']
            data['task-name']   = header_data['task-name']
            data['total-sub-tasks'] = header_data['total-sub-tasks']
            data['from-worker'] = "aggregate_worker"
            data['aggregator-reply-to-queue'] = ''
            data['ok'] = header_data['ok']
            data['error-msg'] = header_data['error-msg']
            data['re-try'] = header_data['re-try']
            data['re-try-count'] = header_data["re-try-cnt"]

            msg_header_data = [data]


            payload_data = { "msg-header" : msg_header_data , "msg-body":[{},] }

            ch.basic_publish(exchange='',
                routing_key='routemanager_queue',
                body=json.dumps(payload_data),
                properties=pika.BasicProperties
                (delivery_mode = 1, # make message persistant
                )
            )
            ch.basic_ack(delivery_tag = method.delivery_tag)
            #cleanup
            ch.queue_delete(queue=self.queue_name)
            self.exit()
        else:
            ch.basic_ack(delivery_tag = method.delivery_tag)
#-------------------------------------------------
if __name__ == '__main__':
    worker_obj = AggregateWorker(queue_name='echo.queue.registration.aggregator')
    worker_obj.run()




