import pika
import json
from dolphind.lib.base_worker import BaseWorker
#from dbconnectors.mysql_connector import Mysql_Connector as mysql

class CorelateWorker(BaseWorker):
    queue_name = "echo.queue.registration.corelate"

    def __init__(self):
        super(CorelateWorker, self).__init__(self.queue_name)

    def merging(self,xl_data):
        """
        This method will merge the data from the list of dict.

        """

        fname = []
        lname = []
        mname = []
        cor_data = {}

        for item in xl_data:
            if item['FirstName'] and item['FirstName'] not in fname:
                fname.append(item['FirstName'])

            if item['MiddleName'] and item['MiddleName'] not in mname:
                mname.append(item['MiddleName'])

            if item['LastName'] and item['LastName'] not in lname:
                lname.append(item['LastName'])


        cor_data['SSN'] = xl_data[0]['SSN']

        cor_data['FirstName'] = fname[0] if fname else ""
        cor_data['MiddleName'] = mname[0] if mname else ""
        cor_data['LastName'] = lname[0] if lname else ""
        return [cor_data]


    def callback(self, ch, method, properties, body):
        """
        1. It get the validated message from validate queue.
        2. It merge the group of message to one single message.
        3. It post back the merged data to Route queue 
        """
        print " Corelate Manager Data :: [x] Received %r" % (body,) 
        data = {}
        #import pdb;pdb.set_trace()
        payload_data = json.loads(body)
        header_data = payload_data['msg-header'][0]
        validated_data=payload_data['msg-body']
        print validated_data
        print header_data
        
        corelate_data = self.merging(validated_data)


        data['task-id'] = header_data['task-id']
        data['sub-task-id'] = header_data['sub-task-id']
        data['task-name'] = header_data['task-name']
        data['from-worker'] = 'corelate_worker'
        data['aggregator-reply-to-queue'] = header_data['aggregator-reply-to-queue']
        data['error-msg'] = header_data['error-msg']
        data['total-sub-tasks'] = header_data['total-sub-tasks']
        data['re-try'] = header_data['re-try']
        data['re-try-cnt'] = header_data['re-try-cnt']
        data['ok'] = header_data['ok']

        if not corelate_data[0]:
            data['ok'] = 'False'
            data['error-msg'] = 'CORRELATE WORKER:Correlation Failed.'

        msg_header_data = [data]
        payload_data['msg-header'] = msg_header_data
        payload_data['msg-body'] = corelate_data
        #import pdb;pdb.set_trace()
        ch.basic_publish(exchange='',
            routing_key='routemanager_queue',
            body=json.dumps(payload_data),
            properties=pika.BasicProperties(
                delivery_mode = 2, # make message persistant
            ))

        print " Send back to Router Queue :: Worker [x] Done"
        ch.basic_ack(delivery_tag = method.delivery_tag)
        

#-------------------------------------------------
if __name__ == '__main__':
    corelate_obj = CorelateWorker()
    corelate_obj.run()
    
