import pika
import yaml
import json
import datetime
from dolphind.lib.base_worker import BaseWorker
from dolphind.lib.mysql_connector import Mysql_Connector as mysql


class StoreWorker(BaseWorker):
	queue_name = "echo.queue.registration.store"

	def __init__(self):
		super(StoreWorker, self).__init__(self.queue_name)

	def store_data(self, sql_data):
		'Stores the final data into SQL.'
		try:
			con_obj = mysql()
			con_obj.connect(host='localhost',username='root',pwd='root',db='DolphinD')
			res = con_obj.select('EMPLOYEE_DETAILS',[],{'SSN':int(sql_data['SSN'])})
			if not res:
				now = str(datetime.datetime.now())
				sql_insert_data =[(int(sql_data['SSN']), sql_data['FirstName'],sql_data['MiddleName'], \
								 sql_data['LastName'],now,now)]
				con_obj.insert('EMPLOYEE_DETAILS',sql_insert_data)
				return True
		except:
			print "Error while inserting record into mysql database"
			return False


	def callback(self, ch, method, properties, body):
		print " Store Manager Data :: [x] Received %r" % (body,)	
		data = {}
		payload_data = yaml.load(body)
		header_data = payload_data['msg-header'][0]
		sql_data=payload_data['msg-body'][0]
		stored = self.store_data(sql_data)

		data['task-id'] = header_data['task-id']
		data['sub-task-id'] = header_data['sub-task-id']
		data['task-name'] = header_data['task-name']
		data['from-worker'] ='store_worker'
		data['aggregator-reply-to-queue'] = header_data['aggregator-reply-to-queue']
		data['error-msg']= header_data['error-msg']
		data['total-sub-tasks']=header_data['total-sub-tasks']
		data['re-try']= header_data['re-try']
		data['re-try-cnt']= header_data['re-try-cnt']
		data['ok']=header_data['ok']

		if not stored:
			data['ok'] = 'False'
			data['error-msg'] = 'STORE WORKER:Error in Data Insertion'

		msg_header_data = [data]
		payload_data['msg-header'] = msg_header_data

		ch.basic_publish(exchange='',
			routing_key='routemanager_queue',
			body=json.dumps(payload_data),
			properties=pika.BasicProperties(
				delivery_mode = 2, # make message persistant
				))
		ch.basic_ack(delivery_tag = method.delivery_tag)

#-------------------------------------------------
if __name__ == '__main__':
	StoreObj=StoreWorker()
	StoreObj.run()
	
