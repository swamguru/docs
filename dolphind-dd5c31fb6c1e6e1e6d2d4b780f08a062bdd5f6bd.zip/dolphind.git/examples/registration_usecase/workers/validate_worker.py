#!/usr/bin/python
import pika
import json
import ConfigParser
from dolphind.lib.base_worker import BaseWorker
from dolphind.lib.cassandra_connector import Cassandra_Connector
from dolphind.utils.utils import config_section_map


def validate_data(data):
	"""Validate data and compress only validate data and return"""
	valid_data = []
	try:
		if data:
			for item in data:
				ssn = str(item['SSN'])
				if ssn:
					if ssn.isdigit() and len(ssn) == 9 :
						if item['FirstName'] or item['MiddleName'] or item['LastName']:
							valid_data.append(item)
	except:
		print 'Error in validation Worker'			
	return valid_data


class ValidateWorker(BaseWorker):
	queue_name = "echo.queue.registration.validate"

	def __init__(self):
		super(ValidateWorker, self).__init__(self.queue_name)

	def callback(self, ch, method, properties, body):
	    print " Validate Worker [x] Received %r" % (body,)
	    #import pdb;pdb.set_trace()
	    data = {}
	    payload_data = json.loads(body)
	    header_data = payload_data['msg-header'][0]
	    body = payload_data['msg-body']
	    valid_data = validate_data(body)
	    data['task-id'] = header_data['task-id']
	    data['sub-task-id'] = header_data['sub-task-id']
	    data['task-name'] = header_data['task-name']
	    data['aggregator-reply-to-queue'] = header_data['aggregator-reply-to-queue']
	    data['from-worker'] = 'validate_worker'
	    data['error-msg']= header_data['error-msg']
	    data['total-sub-tasks']=header_data['total-sub-tasks']
	    data['re-try']= header_data['re-try']
	    data['re-try-cnt']= header_data['re-try-cnt']
	    data['ok']=header_data['ok']

	    if not valid_data:
	    	data['ok'] = 'False'
	    	data['error-msg'] = 'VALIDATE WORKER:Data Not valid'

	    msg_header_data = [data]
	    payload_data['msg-header'] = msg_header_data
	    payload_data['msg-body'] = valid_data
	    ch.basic_publish(exchange='',
	    	routing_key='routemanager_queue',
	    	body=json.dumps(payload_data),
	    	properties=pika.BasicProperties(
	    		delivery_mode = 2, # make message persistant
	    		))
	    ch.basic_ack(delivery_tag = method.delivery_tag)
	    print " Validate :: Worker [x] Done"

#-----------------------------------------------
if __name__ == '__main__':
	ValidObj=ValidateWorker()
	ValidObj.run()


