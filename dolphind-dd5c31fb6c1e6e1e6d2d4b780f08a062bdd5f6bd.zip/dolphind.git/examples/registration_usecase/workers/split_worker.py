#!/usr/bin/env python
# *- coding: utf-8 -*-
import pika
from dolphind.lib.base_worker import BaseWorker
from dolphind.lib.cassandra_connector import Cassandra_Connector
import json
import xlrd
import itertools
import operator
import datetime
import uuid
#from pprint import pprint

# Utility method. Extract rows from XLS file. File name should contain absolute file path + full file name
# Assumes that XLS contains only one sheet.


def get_row_list_from_xlfile(file_name):
    try:
        wb = xlrd.open_workbook(file_name)
        ws = wb.sheet_by_name('Sheet1')
        print file_name
        hd_row = 0
        hd_info = [str(ws.cell_value(hd_row, i)) for i in xrange(ws.ncols)]
        row_dict_list = []
        for row in xrange(hd_row + 1, ws.nrows):
            row_dict = {}
            for col in xrange(ws.ncols):
                cell_type = ws.cell_type(row, col)
                if cell_type == xlrd.XL_CELL_EMPTY:
                    value = None
                elif cell_type == xlrd.XL_CELL_TEXT:
                    value = str(ws.cell_value(row, col))
                elif cell_type == xlrd.XL_CELL_NUMBER:
                    value = int(ws.cell_value(row, col))
                else:
                    value = ws.cell_value(row, col)
                row_dict[hd_info[col]] = value
            row_dict_list.append(row_dict)
        return row_dict_list
    except:
        print "Error in loading and reading the excel file"
        return None

# Utility method. Group by key value


def group_by_key(xl_row_list, key_value):
    xl_row_list.sort(key=operator.itemgetter(key_value))
    group_by_list = []
    for key, items in itertools.groupby(xl_row_list, operator.itemgetter(key_value)):
        group_by_list.append(list(items))
        # pprint(sub_task_list)
    print 'group_by_list length'
    print len(group_by_list)
    return group_by_list


class StartAggregate(object):

    def __init__(self):
        self.connection = pika.BlockingConnection(pika.ConnectionParameters(
            host='localhost'))

        self.channel = self.connection.channel()

        result = self.channel.queue_declare(exclusive=True)
        self.callback_queue = result.method.queue

        self.channel.basic_consume(self.on_response, no_ack=True,
                                   queue=self.callback_queue)

    def on_response(self, ch, method, props, body):
        if self.corr_id == props.correlation_id:
            self.response = body

    def call(self, message):
        self.response = None
        self.corr_id = str(uuid.uuid4())
        self.channel.basic_publish(exchange='',
                                   routing_key='nodemonitor_queue',
                                   properties=pika.BasicProperties(
                                       reply_to=self.callback_queue,
                                       correlation_id=self.corr_id,
                                   ),
                                   body=json.dumps(message))
        print "Message send to Node Monitor :: "
        while self.response is None:
            self.connection.process_data_events()
        print self.response
        return self.response


class SplitWorker(BaseWorker):

    def __init__(self, queue_name='echo.queue.registration.splitter', host='localhost'):
        super(SplitWorker, self).__init__(queue_name, host)

    def callback(self, ch, method, properties, body):

        header_data = {}
        payload_data = json.loads(body)
        header_data = payload_data['msg-header'][0]
        body_data = payload_data['msg-body'][0]

        # Trigger the Node Monitor Queue to create Aggregator worker
        # Wait for the aggreate creation
        node_message = { "worker-to-create" : "aggregator",
                 "queue-to-bind" : "echo.queue.registration.aggregator"+str(header_data['task-id']),
        }
        obj_create_aggregate = StartAggregate()
        response = obj_create_aggregate.call(node_message)
        print " [.] Got %r" % (response,)
        if not response == 'True':
            print "Error :: Did not create aggreate worker push to error queue"
            print "Not Implemented"

        data = {}
        data['task-id'] = header_data['task-id']
        data['sub-task-id'] = header_data['sub-task-id']
        data['task-name'] = header_data['task-name']
        data['total-sub-tasks'] = header_data['total-sub-tasks']
        data['from-worker'] = 'splitter_worker'
        data['aggregator-reply-to-queue'] = node_message['queue-to-bind']
        data['ok'] = header_data['ok']
        data['error-msg'] = header_data['error-msg']
        data['re-try'] = header_data['re-try']
        data['re-try-cnt'] = header_data['re-try-cnt']
        data['task-input-data'] = body_data.get('file-data')

        # Split rows from input file
        input_data_file_name_with_path = data['task-input-data']
        #input_data_file_name_with_path = '/media/sf_Pilot/RouteManager/sample.xlsx'
        row_list = get_row_list_from_xlfile(input_data_file_name_with_path)
        print len(row_list)

        # Group by SSN to create sub-tasks
        sub_task_list = group_by_key(row_list, 'SSN')
        print "Sub Task :: "+str(len(sub_task_list))

        data['total-sub-tasks'] = len(sub_task_list)
        msg_header_data = [data]

        # Insert sub-tasks in to sub-tasks details table in Cassandra
        try:
	    #import pdb;pdb.set_trace()
            con_obj = Cassandra_Connector(key_space='dolphind')
            con_obj.connect()
            task_id = int(data['task-id'])
            now = datetime.datetime.now().replace(microsecond=0)
            sub_task_id = task_id + 100
            for item in sub_task_list:
                new_payload_data = {}
                print sub_task_id
                insert_value_list = [{'id': sub_task_id, 'task_id': task_id, 'status': 'RC', 'request': str(
                    item), 'reply': ' ', 'subm_time': now, 'error': ' '}]
                con_obj.insert('sub_task_details', insert_value_list)

                # Post the sub-task details to Route Queue
                msg_header_data[0]['sub-task-id'] = sub_task_id
                new_payload_data["msg-header"] = msg_header_data
                new_payload_data["msg-body"] = item
                ch.basic_publish(exchange='',
                    routing_key='routemanager_queue',
                    body=json.dumps(new_payload_data),
                    properties=pika.BasicProperties
                    (delivery_mode = 1, # make message persistant
                    )
                )
                sub_task_id += 1

        except Exception as e:
            print "Error Split Worker - Could not insert sub-task record into sub-task-details table" + str(e)
        ch.basic_ack(delivery_tag = method.delivery_tag)

#-------------------------------------------------
if __name__ == '__main__':
    worker_obj = SplitWorker()
    worker_obj.run()









