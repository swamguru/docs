mysqluser='root'
mysqpass='root'
mysqlDB='DolphinD'
echo
echo
echo "Creating Cassandra schema................."
#cqlsh<$DIR && '/CassandraDolphinDTables.cql'
DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
cqlsh<$DIR'/CassandraDolphinDTables.cql'
echo "Done for Cassandra schema................."
echo
echo "Creating MySQL schema................."
mysql -u $mysqluser -p$mysqpass -e 'CREATE DATABASE IF NOT EXISTS '$mysqlDB';'
mysql -u $mysqluser -p$mysqpass $mysqlDB < $DIR'/MySqDolphinDTables.sql'
echo "Done for MySQL schema................."
echo
echo
